import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, Check, ChevronDown,
  CircleHelp, Clock3, Command, ExternalLink, Gauge, History, LayoutDashboard,
  Link2, Menu, MoreHorizontal, Radio, RefreshCw, Settings, ShieldCheck,
  Sparkles, ThumbsUp, Zap, X, AlertCircle
} from 'lucide-react';
import './styles.css';

const EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🙏', '🔥'];
const API = '/api';

function App() {
  const [page, setPage] = useState('Dashboard');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [postUrl, setPostUrl] = useState('');
  const [emoji, setEmoji] = useState('🔥');
  const [count, setCount] = useState('25');
  const [history, setHistory] = useState([]);
  const [health, setHealth] = useState({ state: 'checking', message: 'Memeriksa layanan…' });
  const [notice, setNotice] = useState(null);
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  async function loadData() {
    setRefreshing(true);
    try {
      const [h, r] = await Promise.all([
        fetch(`${API}/health`).then(x => x.json()),
        fetch(`${API}/history`).then(x => x.json())
      ]);
      setHealth({ state: h.integration === 'configured' ? 'connected' : 'limited', message: h.message });
      setHistory(r.items || []);
    } catch {
      setHealth({ state: 'offline', message: 'Backend belum aktif. Jalankan npm run dev.' });
    } finally { setRefreshing(false); }
  }
  useEffect(() => { loadData(); }, []);

  const totals = useMemo(() => ({
    requested: history.reduce((n, x) => n + Number(x.requested_count || 0), 0),
    success: history.reduce((n, x) => n + Number(x.successful_count || 0), 0),
    jobs: history.length
  }), [history]);

  async function startReaction(e) {
    e.preventDefault();
    setNotice(null);
    if (!postUrl.trim()) {
      setNotice({ type: 'error', text: 'Masukkan URL postingan saluran terlebih dahulu.' });
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(`${API}/reactions`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postUrl: postUrl.trim(), emoji, count: Number(count) })
      });
      const data = await response.json();
      if (data.job) setHistory(old => [data.job, ...old.filter(x => x.id !== data.job.id)]);
      if (!response.ok) {
        setNotice({ type: 'error', text: data.error || 'Permintaan tidak dapat diproses.' });
      } else {
        setNotice({ type: 'success', text: 'Permintaan dikonfirmasi oleh server.' });
      }
      await loadData();
    } catch {
      setNotice({ type: 'error', text: 'Tidak dapat menghubungi backend. Pastikan server aktif.' });
    } finally { setBusy(false); }
  }

  const nav = [
    { name: 'Dashboard', icon: LayoutDashboard },
    { name: 'Reaction', icon: Zap },
    { name: 'History', icon: History },
    { name: 'Settings', icon: Settings }
  ];
  const go = (name) => { setPage(name); setMobileOpen(false); setNotice(null); };

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="brand">
        <div className="brand-mark"><Radio size={22} strokeWidth={2.5}/><span /></div>
        <div><div className="brand-name">WA CHANNEL</div><div className="brand-sub">REACTION BOOSTER <span>PRO</span></div></div>
        <button className="icon-btn close-menu" onClick={() => setMobileOpen(false)} aria-label="Tutup menu"><X size={18}/></button>
      </div>
      <div className="workspace-label">WORKSPACE</div>
      <div className="workspace"><div className="workspace-avatar">W</div><div className="workspace-copy"><strong>Personal workspace</strong><span>Free workspace</span></div><ChevronDown size={15}/></div>
      <div className="nav-label">MENU UTAMA</div>
      <nav>{nav.map(item => <button key={item.name} className={`nav-item ${page === item.name ? 'active' : ''}`} onClick={() => go(item.name)}><item.icon size={18}/><span>{item.name}</span>{item.name === 'Reaction' && <span className="nav-new">NEW</span>}</button>)}</nav>
      <div className="sidebar-spacer"/>
      <div className="sidebar-status"><div className="status-orb"><ShieldCheck size={18}/></div><div><strong>Secure workspace</strong><span>Data tersimpan lokal</span></div><Check size={15} className="green-check"/></div>
      <div className="sidebar-bottom"><span>WA Booster <b>v1.0.0</b></span><button className="icon-btn" aria-label="Bantuan" onClick={() => setNotice({type:'info',text:'Backend menyediakan API dan database lokal. Integrasi resmi untuk mengirim reaction masih perlu disiapkan.'})}><CircleHelp size={17}/></button></div>
    </aside>
    {mobileOpen && <button className="scrim" aria-label="Tutup menu" onClick={() => setMobileOpen(false)}/>}

    <main className="main">
      <header className="topbar">
        <div className="top-left"><button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Buka menu"><Menu size={20}/></button><div className="breadcrumbs"><span>Workspace</span><span className="crumb-slash">/</span><strong>{page}</strong></div></div>
        <div className="top-actions"><div className={`connection-pill ${health.state}`}><span className="pulse-dot"/>{health.state === 'connected' ? 'Integration connected' : health.state === 'offline' ? 'Backend offline' : 'Integration not connected'}</div><button className="icon-btn notification" aria-label="Notifikasi" onClick={() => setNotice({type:'info',text:health.message})}><Bell size={18}/><i/></button><div className="avatar">WG</div></div>
      </header>

      <div className="content">
        {page === 'Dashboard' && <Dashboard history={history} totals={totals} health={health} refreshing={refreshing} loadData={loadData} go={go} />}
        {page === 'Reaction' && <ReactionPage postUrl={postUrl} setPostUrl={setPostUrl} emoji={emoji} setEmoji={setEmoji} count={count} setCount={setCount} busy={busy} startReaction={startReaction} notice={notice} health={health} />}
        {page === 'History' && <HistoryPage history={history} refreshing={refreshing} loadData={loadData} />}
        {page === 'Settings' && <SettingsPage health={health} />}
        {notice && page !== 'Reaction' && <div className={`toast ${notice.type}`}><AlertCircle size={17}/>{notice.text}<button onClick={() => setNotice(null)}><X size={15}/></button></div>}
        <footer className="footer"><span>© 2026 WA Channel Reaction Booster</span><span><i/> System status: {health.state === 'offline' ? 'Backend offline' : 'API available'}</span></footer>
      </div>
    </main>
  </div>;
}

function PageTitle({eyebrow, title, subtitle, action}) {
  return <div className="page-title"><div><div className="eyebrow"><span/>{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>;
}
function Dashboard({history, totals, health, refreshing, loadData, go}) {
  const cards = [
    { label:'Total reaction diminta', value:totals.requested.toLocaleString('id-ID'), icon:ThumbsUp, tone:'mint', note:'Akumulasi dari riwayat' },
    { label:'Reaction berhasil', value:totals.success.toLocaleString('id-ID'), icon:Check, tone:'green', note:'Terkonfirmasi server' },
    { label:'Total aktivitas', value:totals.jobs.toLocaleString('id-ID'), icon:Activity, tone:'violet', note:'Permintaan tercatat' },
    { label:'Success rate', value:totals.requested ? `${Math.round(totals.success/totals.requested*100)}%` : '—', icon:Gauge, tone:'amber', note:'Berdasarkan hasil nyata' }
  ];
  return <>
    <PageTitle eyebrow="OVERVIEW / DASHBOARD" title={<>Control your <span className="text-gradient">engagement.</span></>} subtitle="Pantau aktivitas reaction saluran dalam satu workspace." action={<button className="button secondary refresh-btn" onClick={loadData}><RefreshCw size={15} className={refreshing?'spin':''}/> Refresh data</button>}/>
    <div className="welcome-banner"><div className="banner-glow"/><div className="banner-icon"><Sparkles size={21}/></div><div className="banner-copy"><div className="banner-kicker">YOUR WORKSPACE IS READY</div><h2>Semua insight, satu dashboard.</h2><p>Dashboard siap digunakan. Hubungkan integrasi yang diizinkan untuk mulai mengirim reaction nyata.</p></div><button className="button primary banner-button" onClick={() => go('Reaction')}>Buka Reaction <ArrowUpRight size={16}/></button><div className="banner-decoration">WA<span>.</span></div></div>
    <div className="section-heading"><div><h2>Performance overview</h2><p>Ringkasan berdasarkan aktivitas yang tercatat</p></div><span className="period-tag"><span/> All time</span></div>
    <div className="stats-grid">{cards.map((c,i)=><div className="stat-card" key={c.label}><div className="stat-top"><span>{c.label}</span><div className={`stat-icon ${c.tone}`}><c.icon size={18}/></div></div><div className="stat-value">{c.value}</div><div className="stat-bottom"><span className="stat-note">{c.note}</span>{i===0&&<ArrowUpRight size={14}/>}</div><div className={`card-line ${c.tone}`}/></div>)}</div>
    <div className="dashboard-grid">
      <section className="panel activity-panel"><div className="panel-heading"><div><h3>Recent activity</h3><p>Aktivitas terbaru di workspace kamu</p></div><button className="text-button" onClick={()=>go('History')}>Lihat semua <ArrowUpRight size={14}/></button></div>
      {history.length ? <div className="activity-list">{history.slice(0,4).map(row=><ActivityRow key={row.id} row={row}/>)}</div> : <EmptyState icon={Activity} title="Belum ada aktivitas" desc="Permintaan yang kamu kirim akan muncul di sini."/>}</section>
      <section className="panel integration-panel"><div className="panel-heading"><div><h3>Integration status</h3><p>Status koneksi layanan</p></div><MoreHorizontal size={19}/></div><div className="integration-hero"><div className="integration-logo"><Radio size={25}/></div><div><strong>WhatsApp Channels</strong><span>Channel reaction provider</span></div><span className={`mini-status ${health.state}`}>{health.state==='offline'?'Offline':health.state==='connected'?'Connected':'Pending'}</span></div><div className="integration-divider"/><div className="integration-detail"><span>API backend</span><strong className={health.state==='offline'?'danger-text':'success-text'}><i/>{health.state==='offline'?'Offline':'Available'}</strong></div><div className="integration-detail"><span>Reaction provider</span><strong className="warning-text"><i/>Belum dikonfigurasi</strong></div><div className="integration-info"><AlertCircle size={16}/><span>{health.message}</span></div><button className="button secondary full-button" onClick={()=>go('Settings')}>Konfigurasi integrasi <ArrowUpRight size={15}/></button></section>
    </div>
  </>;
}
function ReactionPage({postUrl,setPostUrl,emoji,setEmoji,count,setCount,busy,startReaction,notice,health}) {
  return <>
    <PageTitle eyebrow="ENGAGEMENT TOOLS / REACTION" title={<>Reaction <span className="text-gradient">studio.</span></>} subtitle="Siapkan permintaan reaction untuk postingan saluran WhatsApp."/>
    <div className="reaction-layout"><section className="panel form-panel"><div className="panel-heading"><div><h3>Buat permintaan reaction</h3><p>Lengkapi detail postingan dan reaction</p></div><span className="step-chip">STEP 01 / 01</span></div>
      <form onSubmit={startReaction}>
        <label className="field-label" htmlFor="post-url">URL postingan saluran <span className="required">*</span></label><div className="input-wrap"><Link2 size={17}/><input id="post-url" type="url" placeholder="https://whatsapp.com/channel/..." value={postUrl} onChange={e=>setPostUrl(e.target.value)} required/><button type="button" aria-label="Buka tautan" className="input-action" onClick={()=>{if(postUrl.startsWith('https://'))window.open(postUrl,'_blank','noopener,noreferrer')}}><ExternalLink size={15}/></button></div><div className="field-help">Gunakan URL postingan saluran yang bisa diakses secara publik.</div>
        <div className="form-divider"/>
        <div className="field-label">Pilih emoji reaction <span className="required">*</span></div><div className="emoji-grid">{EMOJIS.map(e=><button type="button" key={e} className={`emoji-option ${emoji===e?'selected':''}`} onClick={()=>setEmoji(e)} aria-pressed={emoji===e}><span>{e}</span>{emoji===e&&<i><Check size={11}/></i>}</button>)}</div>
        <div className="form-divider"/>
        <label className="field-label" htmlFor="count">Jumlah reaction yang diminta</label><div className="count-control"><button type="button" onClick={()=>setCount(String(Math.max(1,(Number(count)||1)-1)))} aria-label="Kurangi">−</button><input id="count" type="number" min="1" max="1000" value={count} onChange={e=>setCount(e.target.value)} required/><button type="button" onClick={()=>setCount(String(Math.min(1000,(Number(count)||0)+1)))} aria-label="Tambah">+</button></div><div className="field-help">Jumlah 1–1000. Jumlah yang berhasil hanya dihitung setelah dikonfirmasi provider.</div>
        {notice&&<div className={`form-notice ${notice.type}`}><AlertCircle size={17}/><span>{notice.text}</span></div>}
        <div className="form-actions"><button className="button primary start-button" type="submit" disabled={busy}>{busy?<><RefreshCw size={16} className="spin"/> Mengirim permintaan…</>:<>START REACTION <ArrowUpRight size={16}/></>}</button><button className="button secondary" type="button" onClick={()=>{setPostUrl('');setEmoji('🔥');setCount('25')}}><X size={15}/> Reset</button></div>
        <div className="honesty-note"><ShieldCheck size={16}/><span>Permintaan tidak akan ditandai berhasil tanpa konfirmasi dari integrasi yang valid.</span></div>
      </form>
    </section>
    <aside className="reaction-side"><section className="panel preview-panel"><div className="panel-heading"><div><h3>Request preview</h3><p>Ringkasan sebelum dikirim</p></div><Command size={17}/></div><div className="preview-emoji">{emoji}</div><div className="preview-count">{Math.max(0,Number(count)||0).toLocaleString('id-ID')} <span>reaction diminta</span></div><div className="preview-url"><Link2 size={14}/><span>{postUrl||'URL postingan belum diisi'}</span></div><div className="preview-divider"/><div className="preview-row"><span>Jenis reaction</span><strong>{emoji} {emojiName(emoji)}</strong></div><div className="preview-row"><span>Integrasi</span><strong className="warning-text">Belum aktif</strong></div><div className="preview-row"><span>Mode</span><strong>Manual request</strong></div></section>
      <section className="panel process-panel"><div className="process-title"><div className="process-icon"><ShieldCheck size={18}/></div><div><h3>Status proses</h3><p>Transparansi status permintaan</p></div></div><div className="process-step"><span className="step-number done"><Check size={12}/></span><div><strong>Form siap</strong><span>Validasi input di browser</span></div><span className="step-state">READY</span></div><div className="process-step"><span className="step-number"><Clock3 size={12}/></span><div><strong>Backend menerima</strong><span>Dicek saat kamu mengirim</span></div><span className="step-state pending">WAITING</span></div><div className="process-step"><span className="step-number muted"><Zap size={12}/></span><div><strong>Pengiriman reaction</strong><span>Menunggu integrasi resmi</span></div><span className="step-state pending">LOCKED</span></div><div className="process-callout"><AlertCircle size={16}/><span>{health.message}</span></div></section>
    </aside></div>
  </>;
}
function emojiName(e){return ({'👍':'Like','❤️':'Love','😂':'Haha','😮':'Wow','😢':'Sad','🙏':'Pray','🔥':'Fire'})[e]||'Reaction';}
function HistoryPage({history,refreshing,loadData}) {
  return <><PageTitle eyebrow="ACTIVITY / HISTORY" title={<>Activity <span className="text-gradient">history.</span></>} subtitle="Semua permintaan reaction yang tersimpan di database lokal." action={<button className="button secondary" onClick={loadData}><RefreshCw size={15} className={refreshing?'spin':''}/> Refresh</button>}/>
    <section className="panel history-panel"><div className="panel-heading"><div><h3>Riwayat permintaan</h3><p>{history.length} aktivitas tersimpan · maksimum 100 ditampilkan</p></div><span className="period-tag"><span/> Database</span></div>
    {history.length===0?<EmptyState icon={History} title="Riwayat masih kosong" desc="Belum ada permintaan reaction yang tercatat."/>:<div className="table-wrap"><table><thead><tr><th>POSTINGAN</th><th>EMOJI</th><th>DIMINTA</th><th>BERHASIL</th><th>WAKTU</th><th>STATUS</th></tr></thead><tbody>{history.map(row=><tr key={row.id}><td><a className="url-cell" href={row.post_url} target="_blank" rel="noreferrer"><span>{row.post_url}</span><ExternalLink size={12}/></a></td><td className="emoji-cell">{row.emoji}</td><td>{row.requested_count}</td><td>{row.successful_count}</td><td className="time-cell">{formatDate(row.created_at)}</td><td><StatusBadge status={row.status}/></td></tr>)}</tbody></table></div>}
    <div className="history-foot"><ShieldCheck size={15}/> Data disimpan di database SQLite server. Jumlah berhasil hanya berubah jika provider mengonfirmasi.</div></section>
  </>;
}
function SettingsPage({health}) {
  return <><PageTitle eyebrow="WORKSPACE / SETTINGS" title={<>Workspace <span className="text-gradient">settings.</span></>} subtitle="Kelola status layanan dan persiapan integrasi."/>
    <div className="settings-grid"><section className="panel settings-card"><div className="settings-card-head"><div className="settings-icon"><Radio size={20}/></div><div><h3>WhatsApp integration</h3><p>Koneksi provider untuk reaction saluran</p></div><span className="mini-status limited">Pending</span></div><div className="settings-description">{health.message}</div><div className="setting-line"><span>Backend API</span><StatusBadge status={health.state==='offline'?'offline':'available'}/></div><div className="setting-line"><span>Provider adapter</span><StatusBadge status="unavailable"/></div><div className="setting-line"><span>Secrets</span><strong>Server-side only</strong></div><div className="settings-callout"><AlertCircle size={17}/><div><strong>Belum ada provider reaction yang terhubung</strong><p>Tambahkan adapter hanya setelah ada API resmi/diizinkan yang secara eksplisit mendukung reaction pada postingan Channels. Jangan memasukkan password atau OTP WhatsApp.</p></div></div><button className="button secondary" onClick={()=>window.open('https://developers.facebook.com/docs/whatsapp/','_blank','noopener,noreferrer')}>Baca dokumentasi resmi <ExternalLink size={14}/></button></section>
    <section className="panel settings-card"><div className="settings-card-head"><div className="settings-icon purple"><ShieldCheck size={20}/></div><div><h3>Security & privacy</h3><p>Praktik keamanan aplikasi</p></div></div><div className="security-item"><div className="security-check"><Check size={14}/></div><div><strong>Rate limiting API</strong><span>Permintaan dibatasi per menit.</span></div></div><div className="security-item"><div className="security-check"><Check size={14}/></div><div><strong>Validasi URL & emoji</strong><span>Input diperiksa di server.</span></div></div><div className="security-item"><div className="security-check"><Check size={14}/></div><div><strong>Rahasia di server</strong><span>Tidak ada token di frontend.</span></div></div><div className="security-item"><div className="security-check"><Check size={14}/></div><div><strong>Riwayat persisten</strong><span>Disimpan dengan SQLite.</span></div></div></section></div>
  </>;
}
function ActivityRow({row}) {
  return <div className="activity-row"><div className="activity-emoji">{row.emoji}</div><div className="activity-info"><strong>Reaction request <span>· {row.requested_count}x</span></strong><span className="activity-url">{row.post_url}</span><small>{formatDate(row.created_at)}</small></div><div className="activity-result"><StatusBadge status={row.status}/><span>{row.successful_count}/{row.requested_count}</span></div></div>;
}
function StatusBadge({status}) {
  const map={unavailable:['Unavailable','warn'],failed:['Failed','error'],success:['Success','success'],completed:['Completed','success'],offline:['Offline','error'],available:['Available','success'],pending:['Pending','warn']};
  const [label,tone]=map[status]||[status||'Unknown','muted'];
  return <span className={`status-badge ${tone}`}><i/>{label}</span>;
}
function EmptyState({icon:Icon,title,desc}) {return <div className="empty-state"><div className="empty-icon"><Icon size={22}/></div><strong>{title}</strong><p>{desc}</p></div>;}
function formatDate(date) {if(!date)return '—';try{return new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:'short'}).format(new Date(date));}catch{return date;}}
createRoot(document.getElementById('root')).render(<App/>);
