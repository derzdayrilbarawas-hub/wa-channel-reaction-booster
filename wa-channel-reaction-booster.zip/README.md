# WA Channel Reaction Booster

Dashboard React + Vite dengan backend Express dan database SQLite. UI dan riwayat bekerja, tetapi pengiriman reaction nyata sengaja dinonaktifkan sampai tersedia integrasi resmi/diizinkan yang secara eksplisit mendukung reaction pada postingan WhatsApp Channels.

## Prasyarat
- Node.js 20+ dan npm

## Jalankan lokal
```bash
npm install
cp .env.example .env
npm run dev
```
Frontend: http://localhost:5173  
Backend: http://localhost:3001/api/health

Build frontend:
```bash
npm run build
```

## Fitur yang berfungsi
- Navigasi Dashboard, Reaction, History, Settings.
- Responsif mobile dan desktop.
- Form URL, pilihan emoji, jumlah, validasi browser.
- API melakukan validasi ulang URL, emoji, jumlah dan rate limiting.
- Riwayat permintaan disimpan di SQLite.
- Dashboard hanya menghitung hasil berhasil berdasarkan `successful_count` dari database.
- Server mengembalikan HTTP 503 `unavailable` jika integrasi pengiriman belum dikonfigurasi; UI tidak mengarang keberhasilan.

## Integrasi reaction nyata
Jangan menganggap URL postingan saja cukup untuk mengirim reaction. Sebelum implementasi provider:
1. Pastikan dokumentasi resmi dan izin platform secara eksplisit menyediakan aksi reaction untuk postingan Channels.
2. Buat adapter server-side pada `POST /api/reactions` yang memanggil provider yang benar-benar didukung.
3. Simpan token rahasia hanya di environment server/secret manager, jangan di frontend atau repo.
4. Update `successful_count` hanya dari respons provider yang mengonfirmasi keberhasilan. Simpan kegagalan aktual dengan status yang jelas.
5. Tambahkan autentikasi, otorisasi, audit log, dan pembatasan sesuai kebijakan provider sebelum deploy publik.

Backend saat ini sengaja **tidak** mengarang endpoint WhatsApp dan tidak meminta kata sandi atau OTP pengguna. Jika tidak ada API resmi yang mendukung operasi ini, fitur pengiriman tidak dapat diaktifkan dengan aman hanya dari URL.

## Catatan produksi
- Pasang HTTPS, batasi CORS ke domain frontend, dan tambahkan autentikasi sebelum dipublikasikan.
- SQLite cocok untuk prototipe/single instance; pertimbangkan PostgreSQL untuk deployment multi-instance.
- Data lokal berada di `data/reactions.db` (otomatis dibuat).
