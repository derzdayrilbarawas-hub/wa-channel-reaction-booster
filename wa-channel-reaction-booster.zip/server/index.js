import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3001);
const dbPath = path.resolve(process.env.DATABASE_PATH || path.join(__dirname, '../data/reactions.db'));
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS reaction_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_url TEXT NOT NULL,
    emoji TEXT NOT NULL,
    requested_count INTEGER NOT NULL,
    successful_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL
  )
`);
app.use(cors({ origin: process.env.CLIENT_ORIGIN || true }));
app.use(express.json({ limit: '20kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const allowedEmojis = new Set(['👍', '❤️', '😂', '😮', '😢', '🙏', '🔥']);
const validChannelUrl = (raw) => {
  try {
    const u = new URL(raw);
    return u.protocol === 'https:' &&
      (u.hostname === 'whatsapp.com' || u.hostname.endsWith('.whatsapp.com')) &&
      (u.pathname.includes('/channel/') || u.pathname.includes('/channels/'));
  } catch { return false; }
};

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'WA Channel Reaction Booster API',
    integration: 'not_configured',
    message: 'Backend aktif; pengiriman reaction belum terhubung ke integrasi resmi yang mendukung fitur ini.'
  });
});

app.get('/api/history', (_req, res) => {
  const rows = db.prepare('SELECT * FROM reaction_jobs ORDER BY id DESC LIMIT 100').all();
  res.json({ items: rows });
});

app.post('/api/reactions', (req, res) => {
  const { postUrl, emoji, count } = req.body || {};
  if (typeof postUrl !== 'string' || !validChannelUrl(postUrl)) {
    return res.status(400).json({ error: 'Masukkan URL HTTPS postingan saluran WhatsApp yang valid.' });
  }
  if (!allowedEmojis.has(emoji)) return res.status(400).json({ error: 'Emoji tidak didukung.' });
  if (!Number.isInteger(count) || count < 1 || count > 1000) {
    return res.status(400).json({ error: 'Jumlah harus berupa bilangan bulat antara 1 dan 1000.' });
  }

  // Honest by design: never fake delivery. An authorized provider adapter must be implemented
  // here before this endpoint can submit a real reaction.
  const createdAt = new Date().toISOString();
  const message = 'Integrasi pengiriman reaction belum dikonfigurasi. Tidak ada reaction yang dikirim.';
  const result = db.prepare(`
    INSERT INTO reaction_jobs (post_url, emoji, requested_count, successful_count, status, message, created_at)
    VALUES (?, ?, ?, 0, 'unavailable', ?, ?)
  `).run(postUrl, emoji, count, message, createdAt);

  return res.status(503).json({
    error: message,
    job: {
      id: Number(result.lastInsertRowid), post_url: postUrl, emoji,
      requested_count: count, successful_count: 0, status: 'unavailable',
      message, created_at: createdAt
    }
  });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Terjadi kesalahan server.' });
});

app.listen(port, () => console.log(`API berjalan di http://localhost:${port}`));
